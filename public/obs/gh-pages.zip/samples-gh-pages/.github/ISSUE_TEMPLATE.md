# Please read first!
Please use [discuss-webrtc](https://groups.google.com/forum/#!forum/discuss-webrtc) for general technical discussions and questions.

- [ ] I have provided steps to reproduce
- [ ] I have provided browser name and version
- [ ] I have provided a link to the sample here or a modified version thereof

**Note: If the checkboxes above are not checked (which you do after the issue is posted), the issue will be closed.**

## Browser affected

**Browser name including version (e.g. Chrome 64.0.3282.119)**


## Description


## Steps to reproduce


## Expected results


## Actual results

